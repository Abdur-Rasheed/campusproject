import React from 'react'

/**
 * Url param help to get the id  
 */



class Campus extends React.Component{
   
    render(){
       
        // const { urlParams } = match.params.id
      //  console.log(this.urlParams) //to get the id
    return <div>
               this is campus page
        </div>
        

    }
    
}
export default Campus;