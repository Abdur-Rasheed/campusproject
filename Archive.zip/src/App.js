
import './App.css';
import 'tachyons'

function App() {
  return (
    <div className="App tc">
      Welcome to Campus site
    </div>
  );
}

export default App;
